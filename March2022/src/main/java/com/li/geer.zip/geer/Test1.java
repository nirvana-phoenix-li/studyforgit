package com.li.geer;

import com.li.geer.component.Node;

public class Test1 {

    /**
     * 实现要求：
     * 1、根据已有的代码片段，创建二叉搜索树；
     * 2、用中序遍历输出排序结果，结果形如：0，1，2 ，3 ，4， 5， 6， 7， 8， 9，
     * 3、使用递归、非递归二种方式实现遍历；
     * 4、注意编写代码注释。
     */

    public static void main(String[] args) {

        final int[] values = {1, 3, 4, 5, 2, 8, 6, 7, 9, 0};

        System.out.println("Create BST: ");
        Node root = createBinaryTree(values);

        System.out.println("Traversing the BST with recursive algorithm: ");
        inOrderTransvalWithRecursive(root);

        System.out.println("Traversing the BST with iterative algorithm: ");
        inOrderTransvalWithIterate(root);
    }

    // 构建二叉树(对于重复数据的策略视为大于当前节点，放入右侧)
    public static Node createBinaryTree(int[] values) {
        //目前采用常规方法实现，如果考虑到优化查找性能而牺牲一定的插入删除节点性能，可采用avl或者红黑树
        if (values == null || values.length == 0) {
            return null;
        }
        Node root = new Node(values[0]);
        for (int i = 1; i < values.length; i++) {
            Node temp = root;
            if (values[i] >= temp.getValue()) {
                if (temp.getRightNode() == null) {
                    temp.setRightNode(new Node(values[i]));
                }else {

                }


            }
        }
        return null;
        // TODO:
    }

    // 递归实现
    public static void inOrderTransvalWithRecursive(Node node) {

        // TODO:
    }

    // 非递归实现
    public static void inOrderTransvalWithIterate(Node root) {
        // TODO:
    }
}
